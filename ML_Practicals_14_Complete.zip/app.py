from flask import Flask, Response, abort
from pathlib import Path

app = Flask(__name__)
CODE_DIR = Path(__file__).parent / "codes"

@app.route("/")
def home():
    return "Machine Learning Practicals API is running. Use /t/1 to /t/14."

@app.route("/t/<int:number>")
def get_practical(number):
    if number < 1 or number > 14:
        abort(404)
    file_path = CODE_DIR / f"experiment_{number:02d}.py"
    if not file_path.exists():
        abort(404)
    return Response(file_path.read_text(encoding="utf-8"), mimetype="text/plain")
