MACHINE LEARNING LAB - 14 PRACTICALS

URL mapping:
 /t/1  Feature Engineering
 /t/2  PCA
 /t/3  LDA
 /t/4  Multiple Linear Regression
 /t/5  Polynomial Regression
 /t/6  Ridge Regression
 /t/7  Lasso Regression
 /t/8  Logistic Regression
 /t/9  Linear SVM
 /t/10 Nonlinear SVM (RBF)
 /t/11 K-Means
 /t/12 DBSCAN
 /t/13 Ensemble Learning
 /t/14 Q-Learning

Render settings:
Build command: pip install -r requirements.txt
Start command: gunicorn app:app

The Flask app serves the source code as plain text.
Open /t/1 through /t/14 in a browser to view each code file.

In Jupyter, use:
import requests
response = requests.get("https://YOUR-RENDER-SERVICE.onrender.com/t/1")
response.raise_for_status()
print(response.text)

To execute after reviewing the returned code:
exec(response.text)

Note:
Experiment 1 uses the public Scikit-learn Diabetes dataset and adds an age_group
categorical feature. A small number of BMI values are set to missing for
demonstrating imputation; the original dataset is not claimed to contain them.
