import numpy as np

grid_size = 4
start_state = 0
goal_state = 15
blocked_states = {5, 9}
actions = [0, 1, 2, 3]
action_names = ["Up", "Down", "Left", "Right"]
q_table = np.zeros((grid_size * grid_size, len(actions)))

alpha = 0.1
gamma = 0.95
epsilon = 1.0
epsilon_min = 0.05
epsilon_decay = 0.995
episodes = 5000
max_steps = 100

def move(state, action):
    row, col = divmod(state, grid_size)
    if action == 0:
        row = max(0, row - 1)
    elif action == 1:
        row = min(grid_size - 1, row + 1)
    elif action == 2:
        col = max(0, col - 1)
    else:
        col = min(grid_size - 1, col + 1)
    next_state = row * grid_size + col
    if next_state in blocked_states:
        return state
    return next_state

for episode in range(episodes):
    state = start_state
    for step in range(max_steps):
        if np.random.random() < epsilon:
            action = np.random.choice(actions)
        else:
            action = int(np.argmax(q_table[state]))

        next_state = move(state, action)
        reward = 10 if next_state == goal_state else -1
        if next_state in blocked_states:
            reward = -3

        target = reward
        if next_state != goal_state:
            target += gamma * np.max(q_table[next_state])

        q_table[state, action] += alpha * (target - q_table[state, action])
        state = next_state

        if state == goal_state:
            break

    epsilon = max(epsilon_min, epsilon * epsilon_decay)

state = start_state
path = [state]
visited = {state}
for _ in range(30):
    action = int(np.argmax(q_table[state]))
    next_state = move(state, action)
    if next_state == state or next_state in visited:
        break
    path.append(next_state)
    visited.add(next_state)
    state = next_state
    if state == goal_state:
        break

print("Q-Learning Grid World")
print("Episodes:", episodes)
print("Learning rate:", alpha)
print("Discount factor:", gamma)
print("Final exploration probability:", round(epsilon, 4))
print("Learned path:", path)
print("Reached goal:", path[-1] == goal_state)
print("Learned Q-Table:\n", np.round(q_table, 2))
