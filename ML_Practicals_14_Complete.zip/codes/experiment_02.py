import time
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42, stratify=data.target
)

baseline = Pipeline([
    ("scaler", StandardScaler()),
    ("model", LogisticRegression(max_iter=5000))
])
start = time.perf_counter()
baseline.fit(X_train, y_train)
baseline_time = time.perf_counter() - start
baseline_pred = baseline.predict(X_test)

pca_model = Pipeline([
    ("scaler", StandardScaler()),
    ("pca", PCA(n_components=0.95)),
    ("model", LogisticRegression(max_iter=5000))
])
start = time.perf_counter()
pca_model.fit(X_train, y_train)
pca_time = time.perf_counter() - start
pca_pred = pca_model.predict(X_test)

print("Dataset: Breast Cancer Wisconsin")
print("Original features:", X_train.shape[1])
print("PCA components:", pca_model.named_steps["pca"].n_components_)
print("Baseline accuracy:", accuracy_score(y_test, baseline_pred))
print("PCA accuracy:", accuracy_score(y_test, pca_pred))
print("Baseline training time:", round(baseline_time, 5), "seconds")
print("PCA pipeline training time:", round(pca_time, 5), "seconds")
