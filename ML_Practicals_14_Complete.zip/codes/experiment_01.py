import numpy as np
import pandas as pd
from sklearn.datasets import load_diabetes
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

dataset = load_diabetes(as_frame=True)
df = dataset.data.copy()
df["age_group"] = pd.cut(df["age"], bins=3, labels=["Low", "Medium", "High"])
rng = np.random.default_rng(42)
missing_rows = rng.choice(df.index, size=20, replace=False)
df.loc[missing_rows, "bmi"] = np.nan

numeric_features = df.select_dtypes(include=np.number).columns.tolist()
categorical_features = df.select_dtypes(exclude=np.number).columns.tolist()

numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="mean")),
    ("scaler", StandardScaler())
])

categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore", sparse_output=False))
])

preprocessor = ColumnTransformer([
    ("numeric", numeric_pipeline, numeric_features),
    ("categorical", categorical_pipeline, categorical_features)
])

X_ready = preprocessor.fit_transform(df)
print("Dataset: Scikit-learn Diabetes dataset")
print("Original shape:", df.shape)
print("Missing values before preprocessing:", int(df.isnull().sum().sum()))
print("Processed shape:", X_ready.shape)
print("Missing values after preprocessing:", int(np.isnan(X_ready).sum()))
print("Model-ready dataset created successfully.")
