import time
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42, stratify=data.target
)

baseline = Pipeline([
    ("scaler", StandardScaler()),
    ("model", LogisticRegression(max_iter=5000))
])
start = time.perf_counter()
baseline.fit(X_train, y_train)
baseline_time = time.perf_counter() - start
baseline_pred = baseline.predict(X_test)

lda_model = Pipeline([
    ("scaler", StandardScaler()),
    ("lda", LinearDiscriminantAnalysis(n_components=1)),
    ("model", LogisticRegression(max_iter=5000))
])
start = time.perf_counter()
lda_model.fit(X_train, y_train)
lda_time = time.perf_counter() - start
lda_pred = lda_model.predict(X_test)

print("Dataset: Breast Cancer Wisconsin")
print("Original features:", X_train.shape[1])
print("LDA components:", lda_model.named_steps["lda"].n_components)
print("Baseline accuracy:", accuracy_score(y_test, baseline_pred))
print("LDA accuracy:", accuracy_score(y_test, lda_pred))
print("Baseline training time:", round(baseline_time, 5), "seconds")
print("LDA pipeline training time:", round(lda_time, 5), "seconds")
