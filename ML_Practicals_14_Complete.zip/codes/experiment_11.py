import numpy as np
from sklearn.datasets import load_wine
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

data = load_wine()
X = StandardScaler().fit_transform(data.data)

print("Dataset: Wine")
scores = []
for k in range(2, 9):
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = model.fit_predict(X)
    score = silhouette_score(X, labels)
    scores.append((k, score, model.inertia_))
    print("K:", k, "WCSS:", round(model.inertia_, 4), "Silhouette:", round(score, 4))

best_k = max(scores, key=lambda item: item[1])[0]
final_model = KMeans(n_clusters=best_k, random_state=42, n_init=10)
clusters = final_model.fit_predict(X)

print("\nOptimal K by Silhouette Score:", best_k)
print("Cluster labels:", clusters)
print("Cluster centers shape:", final_model.cluster_centers_.shape)
