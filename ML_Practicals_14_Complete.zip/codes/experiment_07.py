import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import Lasso, LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

data = load_diabetes()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42
)

models = {
    "Linear Regression": LinearRegression(),
    "Lasso Regression": Lasso(alpha=0.1, max_iter=10000)
}

for name, estimator in models.items():
    model = Pipeline([
        ("scaler", StandardScaler()),
        ("regression", estimator)
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    coefficients = model.named_steps["regression"].coef_
    print("\n", name)
    print("MSE:", round(mean_squared_error(y_test, predictions), 4))
    print("RMSE:", round(np.sqrt(mean_squared_error(y_test, predictions)), 4))
    print("R-squared:", round(r2_score(y_test, predictions), 4))
    print("Coefficients:", np.round(coefficients, 4))
    if name == "Lasso Regression":
        print("Number of selected features:", int(np.sum(coefficients != 0)))
