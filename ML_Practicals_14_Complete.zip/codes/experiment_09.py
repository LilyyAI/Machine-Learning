from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

data = load_breast_cancer()
X_train, X_test, y_train, y_test = train_test_split(
    data.data, data.target, test_size=0.2, random_state=42, stratify=data.target
)

model = Pipeline([
    ("scaler", StandardScaler()),
    ("classifier", SVC(kernel="linear", C=1.0))
])
model.fit(X_train, y_train)
predictions = model.predict(X_test)

print("Dataset: Breast Cancer Wisconsin")
print("Kernel: Linear")
print("Accuracy:", round(accuracy_score(y_test, predictions), 4))
print("Confusion Matrix:\n", confusion_matrix(y_test, predictions))
print("Classification Report:\n", classification_report(y_test, predictions, target_names=data.target_names))
