import numpy as np
from sklearn.datasets import load_wine
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import DBSCAN
from collections import Counter

data = load_wine()
X = StandardScaler().fit_transform(data.data)

model = DBSCAN(eps=1.5, min_samples=5)
labels = model.fit_predict(X)

counts = Counter(labels)
noise_count = counts.get(-1, 0)
cluster_count = len(set(labels)) - (1 if -1 in labels else 0)

print("Dataset: Wine")
print("DBSCAN parameters: eps=1.5, min_samples=5")
print("Number of clusters:", cluster_count)
print("Number of noise points:", noise_count)
print("Cluster and noise counts:", dict(counts))
print("Labels:", labels)
